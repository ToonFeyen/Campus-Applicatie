package com.example.demo.repository;

import com.example.demo.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface RoomRepository extends JpaRepository<Room, Long> {

    List<Room> findByCampus_Name(String campusName);

    boolean existsByCampus_NameAndNameIgnoreCase(String campusName, String name);

    @Query("""
      select distinct r from Room r
      where r.campus.name = :campusName
        and (:minSeats is null or r.capacity >= :minSeats)
        and not exists (
          select res from Reservation res
          join res.rooms rr
          where rr.id = r.id
            and res.startAt <= :instant
            and res.endAt   >  :instant
        )
    """)
    List<Room> findAvailableAt(String campusName, Integer minSeats, LocalDateTime instant);

    @Query("""
      select distinct r from Room r
      where r.campus.name = :campusName
        and (:minSeats is null or r.capacity >= :minSeats)
        and not exists (
          select res from Reservation res
          join res.rooms rr
          where rr.id = r.id
            and res.endAt  > :fromTs
            and res.startAt < :untilTs
        )
    """)
    List<Room> findAvailableWindow(String campusName, Integer minSeats, LocalDateTime fromTs, LocalDateTime untilTs);
}
