package com.example.demo.dto;

public record RoomDto(
        Long id,
        String name,
        String type,
        Integer capacity,
        Integer floor
) {}

