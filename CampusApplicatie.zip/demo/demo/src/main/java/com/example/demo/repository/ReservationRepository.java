package com.example.demo.repository;

import com.example.demo.model.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    List<Reservation> findByUser_Id(Long userId);

    List<Reservation> findByRooms_Id(Long roomId);

    @Query("""
           select r from Reservation r 
           join r.rooms rm
           where rm.id = :roomId
             and r.endAt > :startAt
             and r.startAt < :endAt
             and (:excludeId is null or r.id <> :excludeId)
           """)
    List<Reservation> findOverlaps(Long roomId, LocalDateTime startAt, LocalDateTime endAt, Long excludeId);
}
