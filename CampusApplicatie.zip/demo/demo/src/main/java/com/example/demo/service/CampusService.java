
package com.example.demo.service;

import com.example.demo.model.Campus;
import com.example.demo.repository.CampusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;

@Service
@Transactional
public class CampusService {

    private final CampusRepository repo;

    public CampusService(CampusRepository repo) {
        this.repo = repo;
    }

    public Campus create(Campus campus) {
        if (campus == null) throw new IllegalArgumentException("Campus is null");
        if (repo.existsById(campus.getName()) || repo.existsByNameIgnoreCase(campus.getName()))
            throw new IllegalArgumentException("Campus bestaat al");
        return repo.save(campus);
    }

    @Transactional(readOnly = true)
    public List<Campus> list() {
        return repo.findAll();
    }

    @Transactional(readOnly = true)
    public Campus get(String name) {
        return repo.findById(name)
                .orElseThrow(() -> new NoSuchElementException("Campus niet gevonden: " + name));
    }

    public Campus update(String name, Campus update) {
        Campus c = get(name);
        c.setAddress(update.getAddress());
        c.setParkingSpots(update.getParkingSpots());
        return c; // JPA dirty checking
    }

    public void delete(String name) {
        repo.deleteById(name);
    }
}

