package com.example.demo.mapper;

import com.example.demo.dto.CampusDto;
import com.example.demo.model.Campus;

public final class CampusMapper {
    private CampusMapper() {}

    public static CampusDto toDto(Campus c) {
        return c == null ? null :
                new CampusDto(c.getName(), c.getAddress(), c.getParkingSpots(), c.getRoomCount());
    }
}
