package com.example.demo.controller;

import com.example.demo.model.Campus;
import com.example.demo.service.CampusService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/campus")
public class CampusController {

    private final CampusService service;

    public CampusController(CampusService service) { this.service = service; }

    // CREATE
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Campus create(@RequestBody Campus body) {
        return service.create(body);
    }

    // READ (list)
    @GetMapping
    public List<Campus> list() {
        return service.list();
    }

    // READ (one)
    @GetMapping("/{name}")
    public Campus get(@PathVariable String name) {
        return service.get(name);
    }

    // UPDATE
    @PutMapping("/{name}")
    public Campus update(@PathVariable String name, @RequestBody Campus body) {
        return service.update(name, body);
    }

    // DELETE
    @DeleteMapping("/{name}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String name) {
        service.delete(name);
    }
}
