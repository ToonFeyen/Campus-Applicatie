package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService service;
    public UserController(UserService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public User create(@RequestBody User u) { return service.create(u); }

    @GetMapping
    public List<User> list(@RequestParam(value = "nameMatches", required = false) String nameMatches) {
        return service.list(nameMatches);
    }

    @GetMapping("/{id}")
    public User get(@PathVariable Long id) { return service.get(id); }

    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @RequestBody User update) { return service.update(id, update); }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { service.delete(id); }
}
