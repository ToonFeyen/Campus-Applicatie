package com.example.demo.service;

import com.example.demo.model.Campus;
import com.example.demo.model.Room;
import com.example.demo.repository.CampusRepository;
import com.example.demo.repository.RoomRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.NoSuchElementException;

@Service
@Transactional
public class RoomService {

    private final RoomRepository rooms;
    private final CampusRepository campuses;

    public RoomService(RoomRepository rooms, CampusRepository campuses) {
        this.rooms = rooms;
        this.campuses = campuses;
    }

    private Campus campus(String campusName) {
        return campuses.findById(campusName)
                .orElseThrow(() -> new NoSuchElementException("Campus niet gevonden: " + campusName));
    }

    public List<Room> list(String campusName) {
        campus(campusName);
        return rooms.findByCampus_Name(campusName);
    }

    public List<Room> search(String campusName, Integer minSeats, LocalDateTime availableFrom, LocalDateTime availableUntil) {
        campus(campusName);

        boolean hasFrom = availableFrom != null;
        boolean hasUntil = availableUntil != null;

        if (!hasFrom && !hasUntil) {
            return rooms.findByCampus_Name(campusName);
        }
        if (hasFrom && hasUntil) {
            if (!availableFrom.isBefore(availableUntil)) {
                throw new IllegalArgumentException ("Startdatum moet voor de einddatum liggen");
            }
            return rooms.findAvailableWindow(campusName, minSeats, availableFrom, availableUntil);
        }
        LocalDateTime instant = hasFrom ? availableFrom : availableUntil;
        return rooms.findAvailableAt(campusName, minSeats, instant);
    }

    public Room create(String campusName, Room body) {
        Campus c = campus(campusName);
        if (rooms.existsByCampus_NameAndNameIgnoreCase(campusName, body.getName())) {
            throw new IllegalArgumentException("Lokaal naam bestaat al binnen deze campus");
        }
        body.setCampus(c);
        return rooms.save(body);
    }

    public Room get(String campusName, Long id) {
        campus(campusName);
        return rooms.findById(id)
                .filter(r -> r.getCampus().getName().equals(campusName))
                .orElseThrow(() -> new NoSuchElementException("Lokaal niet gevonden voor deze campus"));
    }

    public Room update(String campusName, Long id, Room update) {
        Room r = get(campusName, id);
        if (!r.getName().equalsIgnoreCase(update.getName())
                && rooms.existsByCampus_NameAndNameIgnoreCase(campusName, update.getName())) {
            throw new IllegalArgumentException("Lokaal naam bestaat al binnen deze campus");
        }
        r.setName(update.getName());
        r.setType(update.getType());
        r.setCapacity(update.getCapacity());
        r.setFloor(update.getFloor());
        return r;
    }

    public void delete(String campusName, Long id) {
        get(campusName, id);
        rooms.deleteById(id);
    }
}
