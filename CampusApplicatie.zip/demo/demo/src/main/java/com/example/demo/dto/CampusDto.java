package com.example.demo.dto;

public record CampusDto(
        String name,
        String address,
        Integer parkingSpots,
        Integer roomCount // read-only bij responses
) {}
