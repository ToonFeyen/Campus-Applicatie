package com.example.demo.service;

import com.example.demo.model.Reservation;
import com.example.demo.model.Room;
import com.example.demo.model.User;
import com.example.demo.repository.ReservationRepository;
import com.example.demo.repository.RoomRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;

@Service
@Transactional
public class ReservationService {

    private final ReservationRepository reservations;
    private final UserRepository users;
    private final RoomRepository rooms;

    public ReservationService(ReservationRepository reservations, UserRepository users, RoomRepository rooms) {
        this.reservations = reservations;
        this.users = users;
        this.rooms = rooms;
    }

    private User user(Long userId) {
        return users.findById(userId).orElseThrow(() -> new NoSuchElementException("User niet gevonden: " + userId));
    }

    private void validateWindow(LocalDateTime start, LocalDateTime end) {
        if (start == null || end == null) throw new IllegalArgumentException("Start en eind datums zijn verplicht");
        if (!start.isBefore(end)) throw new IllegalArgumentException("Startdatum moet voor de einddatum liggen");
        if (end.isBefore(LocalDateTime.now())) throw new IllegalArgumentException("Einddatum mag niet in het verleden liggen");
    }

    public List<Reservation> list(Long userId) {
        user(userId);
        return reservations.findByUser_Id(userId);
    }

    public Reservation get(Long userId, Long reservationId) {
        user(userId);
        return reservations.findById(reservationId)
                .filter(r -> r.getUser().getId().equals(userId))
                .orElseThrow(() -> new NoSuchElementException("Reservatie niet gevonden"));
    }

    public Reservation create(Long userId, Reservation body) {
        var u = user(userId);
        validateWindow(body.getStartAt(), body.getEndAt());
        body.setUser(u);
        if (body.getRooms() == null) {
            body.setRooms(new LinkedHashSet<>());
        } else {
            var unique = new LinkedHashSet<>(body.getRooms());
            if (unique.size() != body.getRooms().size()) {
                throw new IllegalArgumentException("Een Lokaal mag binnen je reservatie maar 1 maal worden gereserveerd");
            }
            body.getRooms().clear(); // rooms koppelen we via PUT endpoint
        }
        return reservations.save(body);
    }

    public Reservation update(Long userId, Long reservationId, Reservation update) {
        var r = get(userId, reservationId);
        validateWindow(update.getStartAt(), update.getEndAt());
        if (!update.getStartAt().equals(r.getStartAt()) || !update.getEndAt().equals(r.getEndAt())) {
            for (Room rm : r.getRooms()) {
                var overlaps = reservations.findOverlaps(rm.getId(), update.getStartAt(), update.getEndAt(), r.getId());
                if (!overlaps.isEmpty()) {
                    throw new IllegalStateException("Lokaal '" + rm.getName() + "' is reeds gereserveerd in deze periode");
                }
            }
        }
        r.setStartAt(update.getStartAt());
        r.setEndAt(update.getEndAt());
        r.setComment(update.getComment());
        return r;
    }

    public void delete(Long userId, Long reservationId) {
        get(userId, reservationId);
        reservations.deleteById(reservationId);
    }

    public Reservation addRoom(Long userId, Long reservationId, Long roomId) {
        var res = get(userId, reservationId);
        var room = rooms.findById(roomId)
                .orElseThrow(() -> new NoSuchElementException("Lokaal niet gevonden: " + roomId));
        if (res.getRooms().stream().anyMatch(r -> r.getId().equals(roomId))) {
            throw new IllegalArgumentException("Dit Lokaal zit al in de reservatie");
        }
        var overlaps = reservations.findOverlaps(roomId, res.getStartAt(), res.getEndAt(), res.getId());
        if (!overlaps.isEmpty()) {
            throw new IllegalStateException("Lokaal is reeds gereserveerd in deze periode");
        }
        res.getRooms().add(room);
        return res;
    }


    @Transactional(readOnly = true)
    public List<Reservation> listForRoom(Long roomId) {
        return reservations.findByRooms_Id(roomId);
    }
}
