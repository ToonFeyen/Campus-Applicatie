package com.example.demo.service;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;

@Service
@Transactional
public class UserService {

    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public User create(User u) {
        if (u == null) throw new IllegalArgumentException("User is null");
        if (repo.existsByEmailIgnoreCase(u.getEmail()))
            throw new IllegalArgumentException("Email reeds in gebruik");
        return repo.save(u);
    }

    @Transactional(readOnly = true)
    public List<User> list(String nameMatches) {
        return (nameMatches == null || nameMatches.isBlank())
                ? repo.findAll()
                : repo.findByNameContainingIgnoreCase(nameMatches);
    }

    @Transactional(readOnly = true)
    public User get(Long id) {
        return repo.findById(id).orElseThrow(() -> new NoSuchElementException("User niet gevonden: " + id));
    }

    public User update(Long id, User update) {
        User u = get(id);
        u.setName(update.getName());
        if (!u.getEmail().equalsIgnoreCase(update.getEmail())
                && repo.existsByEmailIgnoreCase(update.getEmail())) {
            throw new IllegalArgumentException("Email reeds in gebruik");
        }
        u.setEmail(update.getEmail());
        return u;
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
