package com.example.demo.controller;

import com.example.demo.model.Reservation;
import com.example.demo.service.ReservationService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/{userId}/reservations")
public class ReservationController {

    private final ReservationService service;
    public ReservationController(ReservationService service) { this.service = service; }

    @GetMapping
    public List<Reservation> list(@PathVariable Long userId) {
        return service.list(userId);
    }

    @GetMapping("/{reservationId}")
    public Reservation get(@PathVariable Long userId, @PathVariable Long reservationId) {
        return service.get(userId, reservationId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Reservation create(@PathVariable Long userId, @RequestBody Reservation body) {
        return service.create(userId, body);
    }

    @PutMapping("/{reservationId}")
    public Reservation update(@PathVariable Long userId, @PathVariable Long reservationId, @RequestBody Reservation body) {
        return service.update(userId, reservationId, body);
    }

    @DeleteMapping("/{reservationId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long userId, @PathVariable Long reservationId) {
        service.delete(userId, reservationId);
    }

    // room koppelen aan reservatie
    @PutMapping("/{reservationId}/rooms/{roomId}")
    public Reservation addRoom(@PathVariable Long userId, @PathVariable Long reservationId, @PathVariable Long roomId) {
        return service.addRoom(userId, reservationId, roomId);
    }
}
