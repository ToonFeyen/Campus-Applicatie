package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
public class Campus {

    @Id
    private String name;

    private String address;

    private int parkingSpots;

    @OneToMany(mappedBy = "campus", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private Set<Room> rooms = new LinkedHashSet<>();

    // ==== GETTERS/SETTERS ====
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public int getParkingSpots() { return parkingSpots; }
    public void setParkingSpots(int parkingSpots) { this.parkingSpots = parkingSpots; }

    public Set<Room> getRooms() { return rooms; }
    public void setRooms(Set<Room> rooms) { this.rooms = rooms; }

    @Transient
    @JsonProperty("roomCount")
    public int getRoomCount() {
        return rooms == null ? 0 : rooms.size();
    }
}
