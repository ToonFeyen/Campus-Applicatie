package com.example.demo.controller;

import com.example.demo.model.Room;
import com.example.demo.service.ReservationService;
import com.example.demo.service.RoomService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/campus/{campus}/rooms")
public class RoomController {

    private final RoomService service;
    private final ReservationService reservationService;

    public RoomController(RoomService service, ReservationService reservationService) {
        this.service = service;
        this.reservationService = reservationService;
    }

    @GetMapping
    public List<Room> list(
            @PathVariable("campus") String campus,
            @RequestParam(value = "minNumberOfSeats", required = false) Integer minSeats,
            @RequestParam(value = "availableFrom", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime availableFrom,
            @RequestParam(value = "availableUntil", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime availableUntil
    ) {
        if (minSeats == null && availableFrom == null && availableUntil == null) {
            return service.list(campus);
        }
        return service.search(campus, minSeats, availableFrom, availableUntil);
    }

    @GetMapping("/{id}")
    public Room get(@PathVariable("campus") String campus, @PathVariable Long id) {
        return service.get(campus, id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Room create(@PathVariable("campus") String campus, @RequestBody Room body) {
        return service.create(campus, body);
    }

    @PutMapping("/{id}")
    public Room update(@PathVariable("campus") String campus, @PathVariable Long id, @RequestBody Room body) {
        return service.update(campus, id, body);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable("campus") String campus, @PathVariable Long id) {
        service.delete(campus, id);
    }

    @GetMapping("/{id}/reservations")
    public Object reservationsForRoom(@PathVariable("campus") String campus, @PathVariable Long id) {
        service.get(campus, id);
        return reservationService.listForRoom(id);
    }
}
