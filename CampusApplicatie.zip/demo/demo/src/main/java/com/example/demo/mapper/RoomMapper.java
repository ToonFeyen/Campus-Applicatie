package com.example.demo.mapper;

import com.example.demo.dto.RoomDto;
import com.example.demo.model.Room;

public final class RoomMapper {
    private RoomMapper() {}

    public static RoomDto toDto(Room r) {
        return r == null ? null :
                new RoomDto(r.getId(), r.getName(), r.getType(), r.getCapacity(), r.getFloor());
    }
}
