package com.example.demo;

import com.example.demo.model.Reservation;
import com.example.demo.model.User;
import com.example.demo.repository.ReservationRepository;
import com.example.demo.repository.RoomRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.ReservationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


class ReservationServiceTest {

    private ReservationRepository reservationRepository;
    private UserRepository userRepository;
    private RoomRepository roomRepository;

    private ReservationService service;

    @BeforeEach
    void setup() {
        reservationRepository = mock(ReservationRepository.class);
        userRepository = mock(UserRepository.class);
        roomRepository = mock(RoomRepository.class);

        // jouw service constructor (pas aan als die anders is)
        service = new ReservationService(reservationRepository, userRepository, roomRepository);

        // standaard user mock zodat create() een bestaande user vindt
        User u = new User();
        u.setId(1L);
        u.setName("Alice Janssens");
        u.setEmail("alice@ex.com");
        when(userRepository.findById(1L)).thenReturn(Optional.of(u));
    }

    @Test
    void create_rejectsEndBeforeStart() {
        var r = new Reservation();
        r.setStartAt(LocalDateTime.of(2030, 1, 1, 11, 0));
        r.setEndAt(LocalDateTime.of(2030, 1, 1, 10, 0));

        var ex = assertThrows(IllegalArgumentException.class, () -> service.create(1L, r));
        assertTrue(ex.getMessage().toLowerCase().contains("voor")); // bv. "start moet vóór eind"
        verify(reservationRepository, never()).save(any());
    }

    @Test
    void create_rejectsEndInPast() {
        var r = new Reservation();
        r.setStartAt(LocalDateTime.now().minusDays(2));
        r.setEndAt(LocalDateTime.now().minusDays(1));

        var ex = assertThrows(IllegalArgumentException.class, () -> service.create(1L, r));
        assertTrue(ex.getMessage().toLowerCase().contains("verleden")); // bv. "einddatum mag niet in het verleden liggen"
        verify(reservationRepository, never()).save(any());
    }
}
