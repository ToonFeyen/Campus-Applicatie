package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("h2")
class CampusApiIntegrationTest {

    @Autowired
    MockMvc mvc;

    @Test
    void createCampus_thenGetIt() throws Exception {
        String body = """
          {"name":"PROXIMUS","address":"X-straat 9","parkingSpots":140}
        """;

        mvc.perform(post("/campus")
                        .contentType("application/json")
                        .content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("PROXIMUS"));

        mvc.perform(get("/campus/PROXIMUS"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("PROXIMUS"));
    }
}
